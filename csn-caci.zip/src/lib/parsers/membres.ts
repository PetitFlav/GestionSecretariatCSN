import * as XLSX from 'xlsx'
import { normalizeNom, formatDate } from '@/lib/crypto'

export interface MembreRow {
  nom: string
  prenom: string
  civilite: string | null
  licence: string | null
  dateExpiration: string | null   // "Expire le" = expiration licence FFESSM
  email: string | null
  dateNaissance: string | null
  adresse: string | null
  codePostal: string | null
  ville: string | null
  caci: string | null            // Date certificat médical
  // Clé de jointure normalisée
  key: string
}

// Colonnes utiles dans Membres.xlsx (header ligne 4)
const COL_MAP: Record<string, keyof Omit<MembreRow, 'key'>> = {
  'Civilité':          'civilite',
  'Nom':               'nom',
  'Prénom':            'prenom',
  'Licence':           'licence',
  'Expire le':         'dateExpiration',
  'CACI':              'caci',
  'Email':             'email',
  'Date de naissance': 'dateNaissance',
  'Adresse':           'adresse',
  'CP':                'codePostal',
  'Ville':             'ville',
}

export function parseMembres(buffer: ArrayBuffer): {
  membres: MembreRow[]
  errors: string[]
} {
  const workbook = XLSX.read(buffer, { type: 'array', cellDates: true })
  const sheet = workbook.Sheets[workbook.SheetNames[0]]

  // Header en ligne 4 (index 3), données à partir de ligne 5
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
    header: 1,
    raw: false,
    dateNF: 'dd/mm/yyyy',
  }) as unknown[][]

  if (rows.length < 4) {
    return { membres: [], errors: ['Fichier Membres vide ou format incorrect'] }
  }

  // Ligne 4 (index 3) = entêtes
  const headers = rows[3] as string[]
  const errors: string[] = []
  const membres: MembreRow[] = []

  // Vérifier colonnes obligatoires
  const requiredCols = ['Nom', 'Prénom']
  for (const col of requiredCols) {
    if (!headers.includes(col)) {
      errors.push(`Colonne obligatoire manquante dans Membres : "${col}"`)
    }
  }
  if (errors.length > 0) return { membres: [], errors }

  // Données à partir de la ligne 5 (index 4)
  for (let i = 4; i < rows.length; i++) {
    const row = rows[i] as unknown[]
    if (!row || row.length === 0) continue

    const data: Partial<MembreRow> = {}

    headers.forEach((header, colIdx) => {
      const field = COL_MAP[header]
      if (!field) return
      const val = row[colIdx]
      if (val === null || val === undefined || val === '') return

      if (field === 'dateNaissance' || field === 'dateExpiration' || field === 'caci') {
        // Peut être un objet Date ou une string selon XLSX
        if (val instanceof Date) {
          data[field] = formatDate(val)
        } else {
          data[field] = String(val)
        }
      } else if (field === 'codePostal') {
        data[field] = String(val).padStart(5, '0')
      } else {
        data[field] = String(val).trim()
      }
    })

    // Ignorer les lignes sans nom/prénom
    if (!data.nom || !data.prenom) continue

    // Normaliser civilité
    if (data.civilite) {
      const c = data.civilite.toLowerCase()
      if (c.includes('mademoiselle') || c.includes('melle')) data.civilite = 'Mademoiselle'
      else if (c.includes('madame') || c.includes('mme')) data.civilite = 'Madame'
      else data.civilite = 'Monsieur'
    }

    membres.push({
      nom:            data.nom ?? '',
      prenom:         data.prenom ?? '',
      civilite:       data.civilite ?? null,
      licence:        data.licence ?? null,
      dateExpiration: data.dateExpiration ?? null,
      email:          data.email ?? null,
      dateNaissance:  data.dateNaissance ?? null,
      adresse:        data.adresse ?? null,
      codePostal:     data.codePostal ?? null,
      ville:          data.ville ?? null,
      caci:           data.caci ?? null,
      key:            `${normalizeNom(data.nom ?? '')}|${normalizeNom(data.prenom ?? '')}`,
    })
  }

  return { membres, errors }
}
