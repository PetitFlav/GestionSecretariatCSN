import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { version } from '../../package.json'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Gestion Secrétariat CSN',
  description: 'Application de gestion des adhérents du Centre Subaquatique Nantais',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}

export { version }
